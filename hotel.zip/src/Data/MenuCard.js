

const MenuCard = [
    {
        id : 1,
        imgpath : "images/breakfast1.jpg",
        name :"Egg Boil",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"mgbrekfast",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 2,
        imgpath : "images/vadasamber.jpg",
        name :"Vada Sambar",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"mgbrekfast",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 3,
        imgpath : "images/poha.jpg",
        name :"Poha",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"mgbrekfast",
        discount:"2%",
        link:"Order Now"
    },
     {
        id : 4,
        imgpath : "images/idali.jpg",
        name :"Idali",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"mgbrekfast",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 5,
        imgpath : "images/paneerchilli.jpg",
        name :"Paner Chilli",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"starter",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 6,
        imgpath : "images/soyavadi.jpeg",
        name :"Soya Vadi",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"starter",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 7,
        imgpath : "images/vegthali.jpg",
        name :"Veg thali",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"lunch",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 8,
        imgpath : "images/nonvegthali.jpg",
        name :"Non-Veg thali",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"lunch",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 9,
        imgpath : "images/bahubali.jpg",
        name :"Veg Kolhapuri thali",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"lunch",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 10,
        imgpath : "images/mugpakoda.jpg",
        name :"Mug pakoda",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"evbrekfast",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 11,
        imgpath : "images/vadapav.jpg",
        name :"Vada Pav",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"evbrekfast",
        discount:"2%",
        link:"Order Now"
    },

    {
        id : 12,
        imgpath : "images/aloopakoda.jpg",
        name :"Allu Pakoda",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"evbrekfast",
        discount:"2%",
        link:"Order Now"
    },

    {
        id : 13,
        imgpath : "images/pavbhaji.jpg",
        name :"Pav bhaji",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"dinner",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 14,
        imgpath : "images/chikanthali.jpg",
        name :"Chikan Thali",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"dinner",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 15,
        imgpath : "images/chickenbiryani.jpg",
        name :"Chikan Briyani",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"dinner",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 16,
        imgpath : "images/panipuri.jpg",
        name :"Pani Puri",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"chat",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 17,
        imgpath : "images/ragdapuri.jpg",
        name :"Ragada Puri",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"chat",
        discount:"2%",
        link:"Order Now"
    },

    {
        id : 18,
        imgpath : "images/bhel.jpg",
        name :"Bhel",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"chat",
        discount:"2%",
        link:"Order Now"
    },

    {
        id : 19,
        imgpath : "images/falooda.jpg",
        name :"Faluda",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"cold",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 19,
        imgpath : "images/vanilaic.jpg",
        name :"Vanila Ice cream",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"cold",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 20,
        imgpath : "images/coffee.jpg",
        name :"Coffee",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"hot",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 21,
        imgpath : "images/tea.jpg",
        name :"tea",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"hot",
        discount:"2%",
        link:"Order Now"
    },
    {
        id : 22,
        imgpath : "images/manchowsoup.jpg",
        name :"Manchow soup",
        discription:'Some quick example text to build on the.',
        price:"Rs-45",
        category:"hot",
        discount:"2%",
        link:"Order Now"
    }
]






export default MenuCard;