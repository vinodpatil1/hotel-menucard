import React from 'react'

const Footer = () => {
  return (
   <>
    <footer className='footer py-3'>
        <div className="container">
            <div className="row">
                <div className="col-12">
                  <p>All right Reserved this pages</p>
                </div>
            </div>
        </div>
      </footer>
   </>
  )
}

export default Footer;
